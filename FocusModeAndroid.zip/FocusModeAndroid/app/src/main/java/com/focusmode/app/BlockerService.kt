package com.focusmode.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONObject
import java.time.LocalDate

class BlockerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val yt = "com.google.android.youtube"
    private val known = mapOf(
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "snapchat" to "com.snapchat.android",
        "tiktok" to "com.zhiliaoapp.musically",
        "twitter" to "com.twitter.android",
        "whatsapp" to "com.whatsapp",
        "youtube" to yt
    )
    private val loop = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) {}
            handler.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() { handler.removeCallbacks(loop); handler.post(loop) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }

    private fun check() {
        val prefs = getSharedPreferences("fm", MODE_PRIVATE)
        val st = JSONObject(prefs.getString("state", "{}") ?: "{}")
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        val now = System.currentTimeMillis()

        // 1) Study session: only this app (and phone/system screens) allowed
        val ss = st.optJSONObject("session")
        if (ss != null && ss.optLong("endAt") > now) {
            if (pkg != packageName && pkg !in safe()) block("Focus session is on")
            return
        }

        // 2) Daily limits
        val lm = st.optJSONObject("limits") ?: return
        if (now > lm.optLong("start") + lm.optInt("days") * 86400000L) return
        val apps = lm.optJSONArray("apps") ?: return
        val day = LocalDate.now().toString()
        var shorts: Boolean? = null
        for (i in 0 until apps.length()) {
            val a = apps.getJSONObject(i)
            val name = a.optString("name").lowercase().trim()
            val limit = a.optInt("mins") * 60
            val match = if ("shorts" in name) {
                pkg == yt && (shorts ?: hasShorts(root).also { shorts = it })
            } else known.entries.any { it.key in name && it.value == pkg }
            if (!match) continue
            val key = "u_${day}_$name"
            val used = prefs.getInt(key, 0)
            if (used >= limit) { block("Daily limit reached: ${a.optString("name")}"); return }
            prefs.edit().putInt(key, used + 1).apply()
        }
    }

    private fun hasShorts(r: AccessibilityNodeInfo) =
        listOf("reel_recycler", "reel_player_page_container")
            .any { r.findAccessibilityNodeInfosByViewId("$yt:id/$it").isNotEmpty() }

    private fun safe(): Set<String> {
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName
        return setOfNotNull(
            home, "com.android.systemui", "android", "com.android.phone",
            "com.android.server.telecom", "com.android.dialer",
            "com.google.android.dialer", "com.android.emergency"
        )
    }

    private fun block(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }
}
